import core

core.main()